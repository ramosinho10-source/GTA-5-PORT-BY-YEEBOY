package com.yeeboy.gta5port;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_APK = 41;
    private Uri selectedApk;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190, 25, 35)));
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12,12,12));
        getWindow().setNavigationBarColor(Color.rgb(12,12,12));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(22), dp(30), dp(22), dp(22));
        page.setBackgroundColor(Color.rgb(16,16,18));

        TextView brand = text("GTA 5", 38, Color.WHITE, true);
        TextView port = text("PORT", 23, Color.rgb(235,45,55), true);
        TextView dev = text("ANDROID • DEVELOPER YEEBOY", 12, Color.LTGRAY, true);
        page.addView(brand);
        page.addView(port);
        page.addView(dev);

        View gap = new View(this);
        page.addView(gap, new LinearLayout.LayoutParams(1, dp(28)));

        TextView heading = text("УСТАНОВЩИК", 21, Color.WHITE, true);
        page.addView(heading);
        TextView info = text(
            "Это помощник для установки совместимого APK-файла, который вы получили из легального источника.\n\n" +
            "В комплект не входят GTA V, игровые данные, лицензия или файлы Rockstar. Это не официальный продукт Rockstar Games.",
            14, Color.LTGRAY, false);
        page.addView(info);

        Button choose = button("Выбрать APK-файл");
        page.addView(choose, new LinearLayout.LayoutParams(-1, dp(54)));
        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("application/vnd.android.package-archive");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_APK);
        });

        TextView status = text("Файл ещё не выбран", 13, Color.LTGRAY, false);
        page.addView(status);

        Button install = button("Продолжить установку");
        page.addView(install, new LinearLayout.LayoutParams(-1, dp(54)));
        install.setOnClickListener(v -> {
            if (selectedApk == null) {
                Toast.makeText(this, "Сначала выберите APK-файл", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(selectedApk, "application/vnd.android.package-archive");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Не удалось открыть установщик Android", Toast.LENGTH_LONG).show();
            }
        });

        View spacer = new View(this);
        page.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));
        page.addView(text("GTA 5 PORT • YEEBOY  |  VERSION 1.0", 11, Color.GRAY, true));

        setContentView(page);

        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("application/vnd.android.package-archive");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_APK);
        });
        install.setOnClickListener(v -> {
            if (selectedApk == null) {
                Toast.makeText(this, "Сначала выберите APK-файл", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(selectedApk, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { startActivity(intent); }
            catch (Exception e) { Toast.makeText(this, "Android не смог открыть этот APK", Toast.LENGTH_LONG).show(); }
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_APK && resultCode == RESULT_OK && data != null) {
            selectedApk = data.getData();
            Toast.makeText(this, "APK выбран. Нажмите «Продолжить установку».", Toast.LENGTH_LONG).show();
        }
    }
}
