# Как получить APK автоматически

В этой среде нет Android SDK/Gradle, поэтому готовый APK здесь скомпилировать нельзя. В проект добавлен GitHub Actions workflow `.github/workflows/build-apk.yml`, который собирает debug APK в облаке GitHub.

1. Создайте новый пустой репозиторий на GitHub.
2. Загрузите в него всё содержимое этой папки (не сам ZIP-файл).
3. Откройте вкладку **Actions** и разрешите запуск GitHub Actions, если GitHub попросит.
4. Запустите **Build GTA 5 PORT APK** через **Run workflow** (или дождитесь сборки после push в main/master).
5. Откройте завершённый запуск workflow и скачайте артефакт **GTA5-PORT-Yeeboy-APK**.
6. Распакуйте артефакт — внутри будет `app-debug.apk`.

Это APK установщика-помощника, а не GTA V. Игровые файлы в проект не входят.
